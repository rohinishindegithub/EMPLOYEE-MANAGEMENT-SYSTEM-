package com.project.beta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BetaFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BetaFinalApplication.class, args);
	}

}
