package com.project.beta.Controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.beta.Model.Admin;
import com.project.beta.repository.AdminRepo;

@Controller
public class AdminController {

		@Autowired
		private AdminRepo arepo;
		
		@RequestMapping("/")
		public String landing()
		{
			return "register.jsp";
		}
		
		@RequestMapping("/addAddmin")
		public String register(@ModelAttribute Admin ee)
		{
			System.out.println(ee);
			arepo.save(ee);
			return "register.jsp"; 
		}
		@RequestMapping("/login")
		public String login(@RequestParam String email,@RequestParam String password)
		{
			System.out.println(email);
			System.out.println(password);
			
			Admin ob=arepo.findByEmail(email);
			
			
			if(ob!=null && ob.getEmail().equalsIgnoreCase(email) && ob.getPassword().equals(password))
			{
				return "home.jsp";
			}
			else
			{
				return "login.jsp";
			}
			
		}
		
		@RequestMapping("/fetch")
		public String dataFetch(Model data)
		{
			List<Admin> al=arepo.findAll();
			
			data.addAttribute("data",al);
			
			return "datafetch.jsp";
		}
		@RequestMapping("/Delete/{id}")
		public String delete(@PathVariable int id)
		{
			arepo.deleteById(id);
			return "redirect:/fetch";
			
		}
		@RequestMapping("/{id}")
		public String update(@PathVariable int id,Model m)
		{
			Admin ob=arepo.findById(id).orElse(null);
			
			m.addAttribute("data",ob);
			//System.out.println(ob);
			return "edit.jsp";
		}
		
		@RequestMapping("/edit/{id}")
		public String edit(@PathVariable int id,@ModelAttribute Admin ee)
		{
			Admin ob=arepo.findById(id).orElse(null);
			if(ob!=null)
			{
				ob.setName(ee.getName());
				ob.setEmail(ee.getEmail());
				ob.setPassword(ee.getPassword());
				
				arepo.save(ob);
			}
			return "redirect:/fetch";
		}

}
