package com.project.beta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.beta.Model.Admin;

public interface AdminRepo extends JpaRepository<Admin, Integer> {
	public Admin findByEmail(String email);
}
