package com.project.beta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetaFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
